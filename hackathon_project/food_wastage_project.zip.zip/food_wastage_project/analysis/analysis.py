import matplotlib
matplotlib.use('Agg')
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import os

DB_PATH = 'db/food_data.db'
PLOT_DIR = 'static/plots'

# 1. Daily Food Wastage Trend
def food_wastage_trend(df):
    df['date'] = pd.to_datetime(df['date'])
    df['wasted'] = df['prepared_quantity'] - df['consumed_quantity']

    last_month_df = df[df['date'] >= df['date'].max() - pd.Timedelta(days=30)]
    trend = last_month_df.groupby('date')['wasted'].sum()

    plt.figure(figsize=(8, 4))
    trend.index = trend.index.strftime('%Y-%m-%d')
    trend.plot(kind='line', marker='o', color='red')
    plt.title("Last 30 Days Food Wastage Trend")
    plt.xlabel("Date")
    plt.ylabel("Wasted (kg)")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/trend.png")
    plt.close()

    if not trend.empty:
        min_date = trend.idxmin()
        max_date = trend.idxmax()
        min_val = trend.min()
        max_val = trend.max()
        conclusion = f"📅 MINIMUM WASTE: {min_date} → {min_val:.2f} kg\n" \
                     f"📅 MAXIMUM WASTE: {max_date} → {max_val:.2f} kg\n"
        with open('static/trend_summary.txt', 'w', encoding='utf-8') as f:
            f.write(conclusion)

# 2. Meal-wise & Day-wise Wastage
def meal_day_wastage(df):
    df['wasted'] = df['prepared_quantity'] - df['consumed_quantity']
    df['date'] = pd.to_datetime(df['date'])
    last_week = df[df['date'] >= df['date'].max() - pd.Timedelta(days=7)]
    pivot = last_week.groupby(['day', 'meal_type'])['wasted'].mean().unstack()

    pivot.plot(kind='bar', figsize=(8,5))
    plt.title("Avg Wastage by Day & Meal (Last 7 Days)")
    plt.ylabel("Wasted (kg)")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/day_meal.png")
    plt.close()

    summary = last_week.groupby(['day', 'meal_type'])['wasted'].mean()
    if not summary.empty:
        max_combination = summary.idxmax()
        max_value = summary.max()
        conclusion = f"🔍 Highest avg wastage: {max_combination[0]} - {max_combination[1]} → {max_value:.2f} kg."
    else:
        conclusion = "No sufficient data to evaluate meal-wise wastage trend."

    with open("static/day_meal_conclusion.txt", "w", encoding="utf-8") as f:
        f.write(conclusion)

# 3. Plate Waste Ratio
def plate_waste_ratio(df):
    df['date'] = pd.to_datetime(df['date'])
    df['waste_ratio'] = df['plates_wasted'] / df['students_served']
    recent_df = df[df['date'] >= df['date'].max() - pd.Timedelta(days=7)]
    avg_ratio = recent_df.groupby('date')['waste_ratio'].mean()

    plt.figure(figsize=(8,4))
    avg_ratio.index = avg_ratio.index.strftime('%Y-%m-%d')
    avg_ratio.plot(kind='bar', color='orange')
    plt.title("Plate Waste Ratio (Plates Wasted / Students Served)")
    plt.ylabel("Waste Ratio")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/plate_waste.png")
    plt.close()

    warning_text = ""
    if any(avg_ratio > 0.2):
        warning_text = "⚠️ ALERT: Plate waste ratio exceeded 0.2 on some days! Please create awareness about not wasting food.\n\n"
        for date, ratio in avg_ratio.items():
            if ratio > 0.2:
                warning_text += f"{date}: Ratio = {ratio:.2f}\n"
    else:
        warning_text = "✅ Plate waste ratio is under control for all recent days. Keep up the good work!"

    with open("static/plate_alert.txt", "w", encoding="utf-8") as f:
        f.write(warning_text)

# 4. Reused vs Wasted Food
def reused_vs_wasted(df):
    df['date'] = pd.to_datetime(df['date'])
    df['wasted'] = df['prepared_quantity'] - df['consumed_quantity']
    recent_df = df[df['date'] >= df['date'].max() - pd.Timedelta(days=30)]

    grouped = recent_df.groupby('date').agg({
        'wasted': 'sum',
        'reused_or_donated': 'sum'
    }).reset_index()

    plt.figure(figsize=(8, 4))
    bar_width = 0.35
    index = range(len(grouped))

    plt.bar(index, grouped['wasted'], bar_width, label='Wasted', color='red')
    plt.bar([i + bar_width for i in index], grouped['reused_or_donated'], bar_width, label='Reused/Donated', color='blue')

    plt.xlabel('Date')
    plt.ylabel('Quantity (kg)')
    plt.title('Reused vs Wasted Food (Last 30 Days)')
    plt.xticks([i + bar_width / 2 for i in index], grouped['date'].dt.strftime('%Y-%m-%d'), rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/reuse_vs_waste.png")
    plt.close()

    advice = ""
    high_waste_days = grouped[grouped['wasted'] > 250]
    if not high_waste_days.empty:
        advice += "Conclusion: The following days had food wastage over 250 kg. It's better to donate more food on these days:\n"
        for _, row in high_waste_days.iterrows():
            advice += f"{row['date'].strftime('%Y-%m-%d')} - Wasted: {row['wasted']} kg\n"

    with open("static/reuse_advice.txt", "w", encoding="utf-8") as f:
        f.write(advice)

# 5. Predict Next Day Consumption
def predict_consumption(df):
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date')
    df['predicted'] = df['consumed_quantity'].rolling(window=3).mean()

    plt.figure(figsize=(8, 4))
    plt.plot(df['date'].dt.strftime('%Y-%m-%d'), df['consumed_quantity'], label='Predicted', marker='o')
    plt.plot(df['date'].dt.strftime('%Y-%m-%d'), df['predicted'], label='Actual', linestyle='--', color='green')
    plt.title("Food Consumption Prediction")
    plt.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/prediction.png")
    plt.close()

# 6. Food Sharing Alerts + Worst Days
def food_alerts(df):
    df['wasted'] = df['prepared_quantity'] - df['consumed_quantity']
    df['waste_percent'] = (df['wasted'] / df['prepared_quantity']) * 100
    alerts = df[df['waste_percent'] > 30].drop_duplicates(subset=['date', 'meal_type'])

    alert_text = "FOOD SHARING ALERTS (Wastage > 30%):\n"
    for _, row in alerts.iterrows():
        alert_text += f"{row['date'].strftime('%Y-%m-%d')} ({row['meal_type']}): Wasted {row['waste_percent']:.1f}%\n"

    worst_days = df.groupby('date')['waste_percent'].mean().sort_values(ascending=False).head(3)
    alert_text += "\nTOP 3 WORST WASTAGE DAYS:\n"
    for date, percent in worst_days.items():
        alert_text += f"{date.strftime('%Y-%m-%d')}: Avg Wastage = {percent:.1f}%\n"

    with open('static/alerts.txt', 'w', encoding='utf-8') as f:
        f.write(alert_text)

# 7. Pie Chart: Food Utilization
def food_utilization_pie(df):
    df['wasted'] = df['prepared_quantity'] - df['consumed_quantity']
    total_consumed = df['consumed_quantity'].sum()
    total_reused = df['reused_or_donated'].sum()
    total_wasted = df['wasted'].sum()

    plt.figure(figsize=(6,6))
    plt.pie([total_consumed, total_wasted, total_reused],
            labels=['Consumed', 'Wasted', 'Reused'],
            autopct='%1.1f%%',
            colors=['#8BC34A', '#F44336', '#03A9F4'])
    plt.title("Total Food Utilization")
    plt.savefig(f"{PLOT_DIR}/utilization_pie.png")
    plt.close()

# 8. Pie Chart: Meal Type Wastage
def meal_type_wastage_pie(df):
    df['wasted'] = df['prepared_quantity'] - df['consumed_quantity']
    totals = df.groupby('meal_type')['wasted'].sum()

    plt.figure(figsize=(6,6))
    plt.pie(totals, labels=totals.index, autopct='%1.1f%%', startangle=140)
    plt.title("Meal Type Contribution to Wastage")
    plt.savefig(f"{PLOT_DIR}/meal_wastage_pie.png")
    plt.close()

    most_wasted_meal = totals.idxmax()
    wasted_kg = round(totals.max(), 2)
    advice = f"Conclusion: '{most_wasted_meal}' contributes the highest to food wastage with approximately {wasted_kg} kg wasted. Special care should be taken to reduce wastage during this meal."

    with open("static/meal_advice.txt", "w", encoding="utf-8") as f:
        f.write(advice)

# 9. Weekly Insights
def weekly_insights(df):
    df['wasted'] = df['prepared_quantity'] - df['consumed_quantity']
    df['date'] = pd.to_datetime(df['date'])
    recent_df = df[df['date'] >= df['date'].max() - pd.Timedelta(days=7)]

    weekly_waste = round(recent_df['wasted'].sum(), 2)
    weekly_attendance = round(recent_df['students_served'].mean(), 2)
    meal_waste = recent_df.groupby('meal_type')['wasted'].sum()
    top_meal = meal_waste.idxmax() if not meal_waste.empty else "N/A"

    return {
        'weekly_waste': weekly_waste,
        'weekly_attendance': weekly_attendance,
        'top_meals': top_meal
    }

# Master function to run all analysis
def run_all_analysis():
    if not os.path.exists(DB_PATH):
        print("Database not found.")
        return

    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query("SELECT * FROM food_log", conn)
    conn.close()

    if df.empty:
        print("No data available.")
        return

    food_wastage_trend(df)
    meal_day_wastage(df)
    plate_waste_ratio(df)
    reused_vs_wasted(df)
    predict_consumption(df)
    food_alerts(df)
    food_utilization_pie(df)
    meal_type_wastage_pie(df)
    print(" All analysis graphs saved.")
