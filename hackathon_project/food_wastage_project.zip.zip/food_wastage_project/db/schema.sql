-- Table to store food entry logs
CREATE TABLE IF NOT EXISTS food_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    day TEXT,
    meal_type TEXT,
    prepared_quantity REAL,
    consumed_quantity REAL,
    students_served INTEGER,
    plates_wasted INTEGER,
    reused_or_donated REAL
);

-- Table to store student feedback
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    rating INTEGER,
    comment TEXT
);
