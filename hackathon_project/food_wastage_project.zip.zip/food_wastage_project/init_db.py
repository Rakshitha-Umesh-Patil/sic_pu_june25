import sqlite3

# Connect to the database (this will create food_data.db if not exist)
conn = sqlite3.connect('db/food_data.db')

# Open the SQL schema file and execute its content
with open('db/schema.sql', 'r') as f:
    conn.executescript(f.read())

conn.commit()
conn.close()

print("✅ Database created and initialized successfully.")
