from flask import Flask, render_template, request, redirect
import sqlite3
import pandas as pd
from analysis.analysis import run_all_analysis, weekly_insights

app = Flask(__name__)

# Home Dashboard
@app.route('/')
def dashboard():
    run_all_analysis()  # Generate charts and summaries

    # Helper to read text files
    def read_file(path, default="Not available"):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            return default

    # Read all summaries
    alerts_text = read_file('static/alerts.txt')
    trend_conclusion = read_file('static/trend_summary.txt')
    plate_message = read_file('static/plate_alert.txt')
    reuse_advice = read_file('static/reuse_advice.txt')
    meal_type_conclusion = read_file('static/meal_advice.txt')
    day_meal_conclusion = read_file('static/day_meal_conclusion.txt')  # ✅

    # Database connection
    conn = sqlite3.connect('db/food_data.db')
    cursor = conn.cursor()

    # Feedback
    cursor.execute("SELECT AVG(rating) FROM feedback")
    avg_rating = cursor.fetchone()[0]
    avg_rating = round(avg_rating, 2) if avg_rating else "No ratings yet"

    cursor.execute("SELECT date, comment FROM feedback ORDER BY id DESC LIMIT 5")
    recent_comments = cursor.fetchall()

    # Format feedback dates (remove 00:00:00)
    formatted_comments = []
    for date, comment in recent_comments:
        try:
            date_str = pd.to_datetime(date).strftime('%Y-%m-%d')
        except:
            date_str = str(date)
        formatted_comments.append((date_str, comment))

    # Weekly insights
    df = pd.read_sql_query("SELECT * FROM food_log", conn)
    conn.close()
    insights = weekly_insights(df)

    return render_template('dashboard.html',
                           alerts=alerts_text,
                           avg_rating=avg_rating,
                           comments=formatted_comments,
                           weekly_waste=insights['weekly_waste'],
                           weekly_attendance=insights['weekly_attendance'],
                           top_meals=insights['top_meals'],
                           trend_conclusion=trend_conclusion,
                           plate_message=plate_message,
                           reuse_advice=reuse_advice,
                           meal_type_conclusion=meal_type_conclusion,
                           day_meal_conclusion=day_meal_conclusion)  # ✅

# Add Data Form
@app.route('/add')
def add_data():
    return render_template('add_data.html')

# Submit Food Data
@app.route('/submit', methods=['POST'])
def submit_data():
    data = (
        request.form['date'],
        request.form['day'],
        request.form['meal_type'],
        float(request.form['prepared']),
        float(request.form['consumed']),
        int(request.form['students']),
        int(request.form['plates']),
        float(request.form['donated'])
    )
    conn = sqlite3.connect('db/food_data.db')
    c = conn.cursor()
    c.execute('INSERT INTO food_log VALUES (NULL,?,?,?,?,?,?,?,?)', data)
    conn.commit()
    conn.close()
    return redirect('/')

# Feedback Form
@app.route('/feedback')
def feedback_form():
    return render_template('feedback.html')

# Submit Feedback
@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    date = request.form['date']
    rating = int(request.form['rating'])
    comment = request.form['comment']

    conn = sqlite3.connect('db/food_data.db')
    c = conn.cursor()
    c.execute('INSERT INTO feedback (date, rating, comment) VALUES (?, ?, ?)', (date, rating, comment))
    conn.commit()
    conn.close()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
